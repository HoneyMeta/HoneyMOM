# 交付包：某转向器壳体铸造厂（foundry-housing）

生成时间 2026-11-05 07:49:05，蜂元虚拟工厂。格式：蜂元交付包 点表格式 v1（和蜂元智能 MES 接入规范一致）。

## 文件

| 文件 | 内容 |
|---|---|
| README.md | 本说明 |
| points.xlsx | 设备（29 台）、点表（636 行）、协议、说明 四张表 |
| layout.dxf | 平面布置图（DXF R12，单位米），每类一层，设备是带属性的块 |
| models/induction_furnace.glb | 设备三维模型（glTF 2.0 二进制，米，Y 向上） |
| models/treatment.glb | 设备三维模型（glTF 2.0 二进制，米，Y 向上） |
| models/sand_system.glb | 设备三维模型（glTF 2.0 二进制，米，Y 向上） |
| models/molding_line.glb | 设备三维模型（glTF 2.0 二进制，米，Y 向上） |
| models/cooling_line.glb | 设备三维模型（glTF 2.0 二进制，米，Y 向上） |
| models/shot_blast.glb | 设备三维模型（glTF 2.0 二进制，米，Y 向上） |
| models/cnc.glb | 设备三维模型（glTF 2.0 二进制，米，Y 向上） |
| models/deburr_cell.glb | 设备三维模型（glTF 2.0 二进制，米，Y 向上） |
| models/inspection.glb | 设备三维模型（glTF 2.0 二进制，米，Y 向上） |
| models/warehouse.glb | 设备三维模型（glTF 2.0 二进制，米，Y 向上） |
| models/agv_fleet.glb | 设备三维模型（glTF 2.0 二进制，米，Y 向上） |
| models/buffer.glb | 设备三维模型（glTF 2.0 二进制，米，Y 向上） |
| models/cell.glb | 设备三维模型（glTF 2.0 二进制，米，Y 向上） |
| models/plc.glb | 设备三维模型（glTF 2.0 二进制，米，Y 向上） |
| models/sink.glb | 设备三维模型（glTF 2.0 二进制，米，Y 向上） |
| models/switch.glb | 设备三维模型（glTF 2.0 二进制，米，Y 向上） |
| models/gateway.glb | 设备三维模型（glTF 2.0 二进制，米，Y 向上） |
| models/mes.glb | 设备三维模型（glTF 2.0 二进制，米，Y 向上） |
| models/scene.glb | 整厂三维场景：每台设备一个节点，节点名 = 设备编码，extras 里有编码、名称、类型 |

## 坐标系

- 工厂坐标：原点在厂房左下角，X 向右，Y 向上，单位米。设备表的 X(m)/Y(m) 是设备中心；朝向(°) 逆时针为正。
- layout.dxf 和工厂坐标完全一致（$INSUNITS = 6 米）。设备块插入点 = 设备中心，插入角 = 朝向，块里画了一根短线指向设备自身 +X。
- 三维（glTF，Y 向上）：glTF X = 工厂 X，glTF Y = 高度，glTF Z = −工厂 Y；朝向 a 对应绕 +Y 轴转 a。

## 图层（layout.dxf）

| 图层 | 内容 |
|---|---|
| VF_WALL | 墙体 / 厂房外轮廓 |
| VF_AREA | 区域（多边形 + 名称） |
| VF_AISLE | 通道 |
| VF_DEVICE | 设备外形（块，属性 CODE / NAME / TYPE） |
| VF_CONVEYOR | 输送线（块，属性同设备） |
| VF_AGV_PATH | AGV 路径与站点 |
| VF_TEXT | 文字标注 |

块属性：CODE（设备编码，可见）、NAME（设备名称）、TYPE（设备类型）。中文按 \U+XXXX 转义（AutoCAD、ezdxf 都能识别）。

## 协议接入

### OPC UA

- 端点：`opc.tcp://192.168.31.115:4885/vfactory/`（安全策略 None，匿名）
- 命名空间：2 = http://honeymeta.cn/vfactory
- NodeId：ns=2;s=foundry-housing/<设备编码>/<点位>，例如 ns=2;s=foundry-housing/CNC1/Monitoring/Spindle/Load
- 时间戳：SourceTimestamp = 对外时间；动作信号的 SourceTimestamp 是动作发生的精确时刻（毫秒）。数值点带 EngineeringUnits、EURange，支持 HistoryRead。

### MQTT

- Broker：`192.168.31.115:1928`，MQTT 3.1.1
- 点位主题：vfactory/foundry-housing/<区域>/<设备编码>/<点位>，例如 vfactory/foundry-housing/machining/CNC1/Monitoring/Spindle/Load
- 载荷（JSON，retain，只在变化时发）：

```json
{"value": 12.5, "unit": "%", "quality": "good", "ts": "2026-11-04T08:00:00+08:00", "sim_ts": "2026-11-04T08:00:00+08:00", "wall_ts": "2026-11-04T08:00:01.234+08:00"}
```

  quality：good / bad（通讯故障时）；ts 按协议设置是仿真时间或墙钟；动作信号的 ts / sim_ts 精确到毫秒。
- 写入：`<点位主题>/set`，载荷 `{"value": 60}` 或纯数值；回执 `<点位主题>/set/ack`（ok / error / code）。
- 心跳与报工：vfactory/foundry-housing/_status（心跳）、vfactory/foundry-housing/_mes/part（零件事件）、vfactory/foundry-housing/_mes/event（生产日志）
- AGV：vda5050/v2/foundry-housing/<AGV>/state

### Modbus TCP

- 端点：`192.168.31.115:6350`；每台设备一个从站（Unit ID），点表地址写成 `从站:表:地址`，例如 `11:hr:1000`、`11:coil:1000`。
- 地址从 0 起（PDU 地址；4x 寄存器 40001 = 地址 0）；表 hr = 保持寄存器（功能码 03/06/16），coil = 线圈（01/05/15）；保持寄存器同址镜像到输入寄存器（04），线圈镜像到离散输入（02）。
- 默认 float32，字序 ABCD；int16 点按 缩放 换算（工程值 = 原始值 × 缩放 + 偏移）；多寄存器的类型和字序写在点表 备注 里（例如 `float32 ABCD，2 个寄存器`）。
- 运行状态 Common/State 是 int16 状态码：0 待机、1 运行、2 缺料、3 堵料、4 停机、5 换型、6 计划停机；报警是线圈（有报警 = 1）。
- Unit 10：0–1 全厂功率 kW、2–3 全厂电能 kWh（float32），之后每个区域 4 个寄存器

## 动作级信号（节拍分析）

有动作信号的设备：CNC1、CNC2、CNC3、CNC4、CNC5、CNC6、DEB1、MOLD1（点表里 用途 = action / step 的 119 行）。

- 加工中心：防护门关门指令 DoorCloseCmd、关到位 DoorClosed、开到位 DoorOpened；夹具电磁阀 ClampValve、夹紧到位 ClampExtended、松开到位 ClampRetracted；主轴 SpindleRun；程序段号 ProgramStep（10…60 = OP10…OP60，0 = 空闲）；循环 CycleOn（上升沿启动，下降沿结束）、CycleCount。
- 造型线：射砂阀 FillValve、压实气缸 SqueezeValve / SqueezeExtended / SqueezeRetracted、推型气缸 PushValve / PushExtended / PushRetracted、段号 1–4。
- 机器人单元：夹爪 GripperValve / GripperClosed / GripperOpened、工装夹紧 ClampValve / ClampExtended / ClampRetracted、RobotAtHome、段号 1–5。
- 每个动作的用时 = 指令（阀）变化 → 到位传感器变化；设备另给 Actions/Last/<动作> 上次用时（秒）和 Actions/Last/Cycle 上次循环用时。
- 只在变化时发；MQTT 每个变化单独一条，ts 是动作时刻（毫秒）；OPC UA 每个变化写一次，SourceTimestamp 是动作时刻。

## 点表格式

列说明见 points.xlsx 的"说明"表；完整规范见 docs/interface/点表格式.md。
